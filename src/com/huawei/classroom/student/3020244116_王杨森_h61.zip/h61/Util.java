package com.huawei.classroom.student.h61;

public class Util {
    /**
     * 获取随机概率
     * */
    public static double getProbability() {
        return Math.random();
    }
}
